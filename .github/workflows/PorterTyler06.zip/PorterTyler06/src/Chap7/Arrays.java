package Chap7;

import java.util.ArrayList;
import java.util.Scanner;

public class Arrays {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int decision;
		
		do {
			System.out.println("\nPick a mini program to choose from"
					+ "\n1. Reverse Array"
					+ "\n2. Average Array"
					+ "\n3. Eliminate duplicates"
					+ "\n4. Count Occurences"
					+ "\n5. Exit");
				
			decision = input.nextInt();
		
			switch (decision) {
				case 1:
					reverseArray();
					break;
				case 2:
					arrayAverage();
					break;
				case 3:
					eliminateDuplicates();
					break;
				case 4:
					countOccurences();
					break;
				case 5:
					System.exit(0);
					break;
				default:
					System.out.println("Thats not a valid option, please try again!");
					break;	
			}
		} while(true);
	}
	
	public static void reverseArray() {
		int[] array = new int[10];
		
		System.out.println("The array to be reversed >");
		
		for(int i = 0; i < array.length; ++i) {
			array[i] = (int)(Math.random() * 51);
			System.out.println(array[i]);
		}
		
		System.out.println("\nThe array in reverse is >");
		for(int i = 0; i < array.length; ++i) {
			System.out.println(array[9-i]);
		}
	}

	public static void arrayAverage() {
		int[] arrayInt = new int[10];
		double[] arrayDouble = new double[10];
		
		for(int i = 0; i < arrayInt.length || i < arrayDouble.length; ++i) {
			arrayInt[i] = (int)(Math.random() * 51);
			arrayDouble[i] = (int)(Math.random() * 51);
		}

		System.out.println("\nThe random array is > ");
		for(int i = 0; i < 10; ++i) {
			System.out.println(arrayInt[i]);
		}
		double temp = average(arrayDouble);
		System.out.println("\nThe average of the array is -"
				+ "\nAs an int > " + average(arrayInt)
				+ "\nAs a double > " + average(arrayDouble));
	}
	public static int average(int[] array) {
		int total = 0;
		for(int i = 0; i < array.length; ++i) {
			total = total + array[i];
		}
		return (total / array.length);
	}
	public static double average(double[] array) {
		double total = 0;
		for(int i = 0; i < array.length; ++i) {
			total = total + array[i];
		}
		return (total / array.length);
	}

	public static void eliminateDuplicates() {
		ArrayList<Integer> array = new ArrayList<Integer>();
		System.out.println("\nThe array to remove duplicates from is > ");
		for(int i = 0; i < 10; ++i) {
			array.add((int)(Math.random() * 11));
			System.out.println(array.get(i));
		}
		array = eliminateDuplicates(array);
		System.out.println("\nThe duplicates have been removed! > ");
		for(int i = 0; i < array.size(); ++i) {
			System.out.println(array.get(i));
		}
	}
	public static ArrayList<Integer> eliminateDuplicates(ArrayList<Integer> array) {
		int cntr;
		for(int i = 0; i < array.size(); ++i) {
			cntr = 0;
			for(int j = 0; j < array.size(); ++j) {
				if(array.get(i) == array.get(j)) {
					++cntr;
				}
			}
			
			if (cntr != 1) {
				array.remove(i);
			}
		}
		return array;
	}
	
	public static void countOccurences() {
		ArrayList<Integer> array = new ArrayList<Integer>();
		ArrayList<Integer> occurenceCounter = new ArrayList<Integer>();
		ArrayList<Integer> repeated = new ArrayList<Integer>();
		int cntr;
		System.out.print("The random array is > \n");
		for(int i = 0; i < 20; ++i) {
			array.add((int)(Math.random() * (99) + 1));
			System.out.println(array.get(i));
		}

		for(int i = 0; i < array.size(); ++i) {
			cntr = 0;
			for(int j = 0; j < array.size(); ++j) {
				if(array.get(i) == array.get(j)) {
					++cntr;
				}
			}
			
			if (cntr > 1) {
				occurenceCounter.add(cntr);
				repeated.add(array.get(i));
			}
		}
		
		System.out.println("\nThe repeating number(s) are > ");
		for(int i = 0; i < repeated.size(); ++i) {
			if (occurenceCounter.get(i) > 1) {
			System.out.println(repeated.get(i) + " repeated " + occurenceCounter.get(i) + " times");
			}
		}
	}
}