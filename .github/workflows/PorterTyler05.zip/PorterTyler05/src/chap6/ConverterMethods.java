package chap6;

import java.util.Scanner;

public class ConverterMethods {
	
	public static void main(String[] args) {
		int decision;
		do {
			decision = menu();
			output(decision);
		} while(decision != 4);
	}
	
	public static int menu() {
		Scanner input = new Scanner(System.in);
		int decision;
		System.out.println("Currency Converter\n"
				+ "   1. Convert USD to Indian Rupee\n"
				+ "   2. Convert USD to Euro\n"
				+ "   3. Convert USD to British Pound\n"
				+ "   4. Exit\n"
				+ "What would you like to do? > ");
		decision = input.nextInt();
		return decision;
	}
	
	public static void output(int decision) {
		Scanner input = new Scanner(System.in);
		String currency="";
		double exchangeRate=1;
		double converted;
		double amountToConvert;
		switch (decision) {
		case 1:
			currency = "Rupee(s)";
			exchangeRate = 72.282250;
			break;
		case 2:
			currency = "Euro(s)";
			exchangeRate = 0.913465;
			break;
		case 3:
			currency = "Pound(s)";
			exchangeRate = 0.833335;
			break;
		case 4:
			System.out.println("Thanks for using the calculator\n!");
			return;
		default:
			System.out.println("That is not a valid option!\n");
			break;
		}
		
		System.out.println("Exchange rate assumed to be 1 US Dollar to " + exchangeRate + " " + currency);
		System.out.println("How many dollars would you like to convert to " + currency + " > ");
		
		amountToConvert = input.nextDouble();
		converted = calcUSDtoCurrency(amountToConvert, exchangeRate);
		
		System.out.println("You will receive " + converted + " " + currency + " for " + amountToConvert + " dollar(s)");
		System.out.println("\nHow many " + currency + " would you like to convert to dollars > ");
		
		amountToConvert = input.nextDouble();
		converted = calcCurrencyToUSD(amountToConvert, exchangeRate);
		
		System.out.println("You will receive " + converted + " dollar(s) for " + amountToConvert + " " + currency + "\n");
	}
	
	public static double calcUSDtoCurrency(double amountToConvert, double rate ) {
		double converted;
		converted = amountToConvert * rate;
		return converted;
	}
	
	public static double calcCurrencyToUSD(double amountToConvert, double rate) {
		double converted;
		converted = amountToConvert / rate;
		return converted;
	}
}