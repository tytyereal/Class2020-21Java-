package Chap10;

public class Dog {
	
	private String name=null, breed=null;;
	private int age=0;
		
	public Dog() {
	}
	public Dog(String name, String breed, int age) {
		this.name = name;
		this.breed = breed;
		this.age = age;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBreed() {
		return breed;
	}
	public void setBreed(String breed) {
		this.breed = breed;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	public int dogYears() {
		return this.age * 7;
	}
	
	@Override
	public String toString() {
		return this.name + " [breed=" + this.breed + ", age=" + this.age + ", age in dog years=" + dogYears() + "]";
	}
}