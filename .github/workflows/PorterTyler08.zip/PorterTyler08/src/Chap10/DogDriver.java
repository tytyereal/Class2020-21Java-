package Chap10;

import java.util.ArrayList;

public class DogDriver {
	
	public static void main(String[] args) {
		ArrayList<Dog> dog = new ArrayList<Dog>();
		
		Dog temp = new Dog("John", "German Shepherd" , 4);
		dog.add(temp);
		temp = new Dog("Jim", "Bulldog" , 6);
		dog.add(temp);
		temp = new Dog("Jimmy", "Poodle" , 8);
		dog.add(temp);
		temp = new Dog("Joseph", "Labrador Retriever" , 2);
		dog.add(temp);
		temp = new Dog("Johnson", "Beagle" , 9);
		dog.add(temp);
		temp = new Dog("Jacob", "Golden Retriever" , 11);
		dog.add(temp);
		
		temp = new Dog();
		temp.setName("Jonah");
		temp.setBreed("Chihuahua");
		temp.setAge(13);
		dog.add(temp);
		
		temp = new Dog();
		temp.setName("Johnny");
		temp.setBreed("Siberian Husky");
		temp.setAge(4);
		dog.add(temp);

		for(int i=0; i<dog.size(); i++) {
			System.out.println(dog.get(i));
		}
	}
}
