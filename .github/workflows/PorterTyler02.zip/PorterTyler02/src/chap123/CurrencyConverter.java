package chap123;
import java.util.Scanner;

public class CurrencyConverter {
	public static void main(String[] args) {
		int menu;
		double dollars, exchangeRate;
		Scanner input = new Scanner(System.in);
		System.out.println("Currency Converter\n   1. Convert USD to Indead Rupee\n   2. Convert USD to Euro\n   3. Convert USD to British Pound\nWhat would you like to do? > ");
		menu = input.nextInt();
		
		switch(menu) {
		case 1: 
			double rupees;
			exchangeRate = 71.2345;
			
			System.out.println("Exchange rate assumed to be 1 US Dollar to " + exchangeRate + " rupee\n");
			System.out.println("How many dollars would you like to convert to rupees > ");
			
			dollars = input.nextDouble();
			System.out.println("You will receive " + (dollars * exchangeRate) + " rupee(s) for " + dollars + " dollar(s)");
			
			System.out.println("\nHow many rupees would you like to convert to dollars > ");
			
			rupees = input.nextDouble();
			System.out.println("You will receive " + (rupees / exchangeRate) + " dollar(s) for " + rupees + " rupee(s)");
			break;
		case 2:
			double euros;
			exchangeRate = .9004;
			
			System.out.println("Exchange rate assumed to be 1 US Dollar to " + exchangeRate + " Euros\n");
			System.out.println("How many dollars would you like to convert to euros > ");
			
			dollars = input.nextDouble();
			System.out.println("You will receive " + (dollars * exchangeRate) + " euro(s) for " + dollars + " dollar(s)");
			
			System.out.println("\nHow many euros would you like to convert to dollars > ");
			
			euros = input.nextDouble();
			System.out.println("You will receive " + (euros / exchangeRate) + " dollar(s) for " + euros + " euros(s)");
			break;
		case 3:
			double pounds;
			exchangeRate = .8321;
			
			System.out.println("Exchange rate assumed to be 1 US Dollar to " + exchangeRate + " pounds\n");
			System.out.println("How many dollars would you like to convert to pounds > ");
			
			dollars = input.nextDouble();
			System.out.println("You will receive " + (dollars * exchangeRate) + " pound(s) for " + dollars + " dollar(s)");
			
			System.out.println("\nHow many pounds would you like to convert to dollars > ");
			
			pounds = input.nextDouble();
			System.out.println("You will receive " + (pounds / exchangeRate) + " dollar(s) for " + pounds + " pounds(s)");
			break;
		}
	}
}