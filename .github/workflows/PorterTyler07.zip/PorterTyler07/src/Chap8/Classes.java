package Chap8;

import java.util.ArrayList;
import java.util.Scanner;

public class Classes {
	
	public static void main(String[] args) {
		ArrayList<Population> country = new ArrayList<Population>();
		while(true) {
			int decision;
			Scanner input = new Scanner(System.in);
			System.out.println("\nPick an option to choose from"
					+ "\n1. Add Country data"
					+ "\n2. Remove Country data"
					+ "\n3. Display Country data"
					+ "\n4. Exit");
				
			decision = input.nextInt();
		
			switch (decision) {
				case 1:
					country = addCountry(country);
					break;
				case 2:
					country = removeCountry(country);
					break;
				case 3:
					displayCountry(country);
					break;
				case 4:
					System.exit(0);
					break;
				default:
					System.out.println("Thats not a valid option, please try again!");
					break;	
			}	
		}
	}
	
	public static ArrayList<Population> addCountry(ArrayList<Population> country) {
		Scanner input = new Scanner(System.in);
		Population temp = new Population();
		
		System.out.println("\nEnter the name of the country: ");
		String name = input.next();
		temp.setName(name);
		System.out.println(name + " Number of males: ");
		temp.setMales(input.nextInt());
		System.out.println(name + " Number of females: ");
		temp.setFemales(input.nextInt());
		System.out.println(name + " Number of square mile: ");
		temp.setSquareMiles(input.nextDouble());
		System.out.println(name + " Number of states: ");
		temp.setStates(input.nextInt());
		
		country.add(temp);
		return country;
	}
	
	public static ArrayList<Population> removeCountry(ArrayList<Population> country) {
		Scanner input = new Scanner(System.in);
		
		System.out.println("");
		for (int i = 0; i < country.size(); i++) {
			System.out.println(i + ". " + country.get(i).getName());
		}
		System.out.println("\nWhat country would you like to remove?");
		int temp = input.nextInt();
		
		country.remove(temp);
		System.out.println("\nItem succesfully removed!\n");
		return country;
	}
	
	public static void displayCountry(ArrayList<Population> country) {
		for (int i = 0; i < country.size(); i++) {
			System.out.println(country.get(i));
		}
	}
}