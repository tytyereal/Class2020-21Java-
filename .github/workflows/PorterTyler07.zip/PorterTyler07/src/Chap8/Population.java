package Chap8;

public class Population {
	
	private String name;
	private int males;
	private int females;
	private double squareMiles;
	private int states;
	
	Population() {
		
	}
	Population(String n, int m, int f, double sm, int s) {
		this.name=n; 
		this.males=m;
		this.females=f; 
		this.squareMiles=sm;
		this.states=s;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getMales() {
		return males;
	}
	public void setMales(int males) {
		this.males = males;
	}
	public int getFemales() {
		return females;
	}
	public void setFemales(int females) {
		this.females = females;
	}
	public double getSquareMiles() {
		return squareMiles;
	}
	public void setSquareMiles(double d) {
		this.squareMiles = d;
	}
	public int getStates() {
		return states;
	}
	public void setStates(int states) {
		this.states = states;
	}
	
	private int totalPopulation() {
		return (this.males + this.females);
	}
	private double populationPerSqM() {
		return (this.totalPopulation() / this.squareMiles);
	}
	private double populationPerState() {	
		return (this.totalPopulation() / this.states);
	}
	
    @Override
    public String toString() {
        return "\nCountry Name: " + this.name
        				+ "\nTotal Population: " + this.totalPopulation()
        				+ "\nPopulation per Square Mile: " + this.populationPerSqM()
        				+ "\nPopulation per State: " + this.populationPerState();
    }	
}
