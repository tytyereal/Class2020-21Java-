package chap11;

import java.util.ArrayList;
import java.util.Scanner;

public class Driver {
	
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		ArrayList<ShiftWorker> workers = new ArrayList<ShiftWorker>();
		workers.add(new ShiftWorker("Adrian", "Johnson", "937-733-9860", true, 9.70, 30));
		workers.add(new ShiftWorker("Jacob", "Higgens", "937-733-2196", false, 9.80, 32));
		
		ShiftWorker temp = new ShiftWorker();
		System.out.println("Employee's first name: ");
		temp.setFirstName(input.next());
		System.out.println("Employee's last name: ");
		temp.setLastName(input.next());
		System.out.println("Empoyee's phone (XXX-XXX-XXXX): ");
		temp.setPhoneNumber(input.next());
		System.out.println("Shift (True for night False for day): ");
		temp.setNightShift(input.nextBoolean());
		System.out.println("Pay rate per hour: ");
		temp.setPayRate(input.nextDouble());
		System.out.println("Hours worked this period: ");
		temp.setHoursWorked(input.nextDouble());
		workers.add(temp);
		
		System.out.println("Employee List contains " + workers.size() + " employee's: \n");
		
		for(int i=0; i < workers.size(); i++) {
			System.out.println(workers.get(i) + "\n");
		}
	}
}