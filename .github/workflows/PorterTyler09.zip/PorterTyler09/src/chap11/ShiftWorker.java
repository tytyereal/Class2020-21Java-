package chap11;

public final class ShiftWorker extends Employee{
	
	private Boolean nightShift = false;
	private double payRate = 0, hoursWorked = 0;
	
	public ShiftWorker() {
		super();
	}
	public ShiftWorker(String firstName, String lastName, String phoneNumber, Boolean nightShift, double payRate, double hoursWorked) {
		super(firstName, lastName, phoneNumber);
		this.nightShift = nightShift;
		this.payRate = payRate;
		this.hoursWorked = hoursWorked;
	}


	public Boolean getNightShift() {
		return nightShift;
	}
	public void setNightShift(Boolean shift) {
		this.nightShift = shift;
	}
	public double getPayRate() {
		return payRate;
	}
	public void setPayRate(double payRate) {
		this.payRate = payRate;
	}
	public double getHoursWorked() {
		return hoursWorked;
	}
	public void setHoursWorked(double hoursWorked) {
		this.hoursWorked = hoursWorked;
	}
	
	private String shift() {
		if(this.nightShift) {
			return "Night Shift";
		} else {
			return "Morining shift";
		}
	}
	
	private double shiftDiff() {	
		if (this.nightShift) {
			return 1.5;
		} else {
			return 1;
		}
	}
	
	private double totalPay() {
		return payRate * shiftDiff() * hoursWorked;
	}
	
	@Override
	public String toString() {
		return super.toString() + ", Works: " + shift() + ", Hourly pay: $" + payRate + ", Hours Worked: " 
								+ hoursWorked + ", Total Pay for Piriod: $" + String.format("%.2f", totalPay());
	}
}