import java.util.Scanner;

class chap5 {
	public static void main(String[] args) {
		int itemCounter = 1, cashTotal = 225; 
		double price;
		Scanner input = new Scanner(System.in);
		
		System.out.println("Happy Birthday from Auntie & Uncle!");
		System.out.println("  You may purchase up to 6 items with this gift card of $225\n\n");
		
		do {
		System.out.println("Enter the price for item #" + itemCounter + ": ");
		price = input.nextDouble();
		
		while (price < .01) {
			System.out.println("Price must be atleast .01, Try again: ");
			price = input.nextDouble();
		}
		
		while ((cashTotal - price) < 0) {
			System.out.println("You dont have enough money for this item please try again: ");
			price = input.nextDouble();
		}
		
		cashTotal -= price;
		++itemCounter;
		System.out.println("You may buy this item. You Have spent $" + (225 - cashTotal) + " so far.");
		System.out.println("You may buy up to " + (7 - itemCounter) + " more items. Gift card balance:\n$" + cashTotal);
		} while (itemCounter < 7 && cashTotal > 0);
		
		System.out.println("You spent $" + (225 - cashTotal) + " on " + (itemCounter - 1) + " items.\n");
		System.out.println("Balance on gift card is $" + cashTotal +
				". You are done shopping for today,\nBe sure to thank your generous Auntie & Uncle!");
	}
}